
const mongoose = require('mongoose');

const WasteBagSchema = new mongoose.Schema({
    bagSerial: { type: String, unique: true, required: true },
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    pickupDate: { type: Date, required: true },
    status: { type: String, default: 'Pending' },
});

module.exports = mongoose.model('WasteBag', WasteBagSchema);
