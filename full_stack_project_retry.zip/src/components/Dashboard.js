
import React, { useState, useEffect } from 'react';
import axios from '../services/api';

function Dashboard() {
  const [wasteBags, setWasteBags] = useState([]);

  useEffect(() => {
    const fetchWasteBags = async () => {
      try {
        const response = await axios.get('/waste/monitor/USER_ID');
        setWasteBags(response.data);
      } catch (error) {
        console.error('Error fetching waste bags:', error);
      }
    };

    fetchWasteBags();
  }, []);

  return (
    <div>
      <h1>Waste Bag Monitoring</h1>
      <ul>
        {wasteBags.map((bag) => (
          <li key={bag.bagSerial}>
            Serial: {bag.bagSerial}, Status: {bag.status}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default Dashboard;
