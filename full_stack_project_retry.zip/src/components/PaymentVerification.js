
import React, { useState } from 'react';
import axios from '../services/api';

function PaymentVerification() {
  const [serialNumber, setSerialNumber] = useState('');
  const [payment, setPayment] = useState(null);

  const handleVerify = async () => {
    try {
      const response = await axios.get(`/payments/verify/${serialNumber}`);
      setPayment(response.data);
    } catch (error) {
      console.error('Error verifying payment:', error);
    }
  };

  return (
    <div>
      <h1>Payment Verification</h1>
      <input
        type="text"
        placeholder="Enter Serial Number"
        value={serialNumber}
        onChange={(e) => setSerialNumber(e.target.value)}
      />
      <button onClick={handleVerify}>Verify</button>
      {payment && (
        <div>
          <p>Serial: {payment.serialNumber}</p>
          <p>Amount: ${payment.amount}</p>
          <p>Status: {payment.status}</p>
        </div>
      )}
    </div>
  );
}

export default PaymentVerification;
