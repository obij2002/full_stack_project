
const express = require('express');
const router = express.Router();
const Payment = require('../models/Payment');

// Record a Payment
router.post('/record', async (req, res) => {
    const { serialNumber, userId, amount, referenceId } = req.body;

    try {
        const newPayment = new Payment({ serialNumber, userId, amount, referenceId });
        await newPayment.save();
        res.status(201).json({ message: 'Payment recorded successfully!', payment: newPayment });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Verify Payment by Serial Number
router.get('/verify/:serialNumber', async (req, res) => {
    const { serialNumber } = req.params;

    try {
        const payment = await Payment.findOne({ serialNumber });
        if (!payment) {
            return res.status(404).json({ message: 'No payment found for this serial number.' });
        }
        res.status(200).json(payment);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

module.exports = router;
