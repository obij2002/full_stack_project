
const express = require('express');
const router = express.Router();
const WasteBag = require('../models/WasteBag');

// Create a new waste bag
router.post('/create', async (req, res) => {
    const { userId, pickupDate } = req.body;

    try {
        const bagSerial = `${userId}-${Date.now()}`;
        const newBag = new WasteBag({ bagSerial, userId, pickupDate });
        await newBag.save();
        res.status(201).json(newBag);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Monitor waste bags by user
router.get('/monitor/:userId', async (req, res) => {
    const { userId } = req.params;

    try {
        const bags = await WasteBag.find({ userId });
        res.status(200).json(bags);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

module.exports = router;
